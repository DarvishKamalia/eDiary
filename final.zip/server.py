# not important, this just tells Python to avoid generating .pyc files
import sys
sys.dont_write_bytecode = True

# imports, only necessary stuff from bottle
from bottle import route, run, template, request, redirect, static_file
import db

# name of the person signed in
name = ''

# static files, like CSS, fonts, images
@route('/static/<filepath:path>')
def static(filepath):
	return static_file(filepath, 'static')

# homepage
@route('/home')
def home():
	global name
	if name == '':
		redirect('/signin')
	else:
		data = {}
		data['lis'] = db.loadEntries()
		data['name'] = name
		return template('home', data)

# signin
@route('/signin')
def signin():
	global name
	if name == '':
		return template('signin', {})
	else:
		redirect('/home')

# signin POST
@route('/signin', method='POST')
def signin_post():
	global name
	name = request.forms['firstname']
	redirect('/home')

# signout
@route('/signout')
def signout():
	global name
	name = ''
	redirect('/signin')

# log a new entry
@route('/log', method='POST')
def log():
	t = request.forms['text']
	f = request.forms['feel']
	ent = db.newEntry(t, f)
	lis = db.loadEntries()
	lis.insert(0, ent)
	db.storeEntries(lis)
	redirect('/home')

# erase an old entry
@route('/erase/<id>')
def erase(id):
	lis = db.loadEntries()
	i = 0
	while i < len(lis):
		ent = lis[i]
		if id == ent['id']:
			lis.pop(i)
			break
		i = i + 1
	db.storeEntries(lis)
	redirect('/home')

run(reloader=True, debug=True)
